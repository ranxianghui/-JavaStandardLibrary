package com.mvc;

/**
 * 应用配置信息
 * 
 * @author Administrator
 *
 */
public class Config {

}
